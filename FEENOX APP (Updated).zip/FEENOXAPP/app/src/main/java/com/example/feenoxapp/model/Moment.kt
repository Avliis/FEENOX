package com.example.feenoxapp.model

import android.net.Uri

data class Moment(val id: String, val ImgUri: String, val description: String, val date: String)